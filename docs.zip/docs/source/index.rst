.. Time Series Analysis documentation master file

Welcome to the Time Series Analysis Project
===========================================

This project provides an end-to-end pipeline for analyzing time series data using Python.

Contents:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   timeseries_py
